
//HÄMTA DATA FRÅN DATABASEN MED API ANROP ... 

const data = JSON.parse('[ { "id": 0, "movie": { "id": 0, "ageLimit": 0, "description": "string", "duration": "string", "genre": "string", "language": "string", "title": "Mulan", "image" : "images/movie-1.webp", "rating" : 8.2, "youtube_link" : "https://www.youtube.com/embed/sEQjLQA9qW4" }, "theater": { "availableSeats": 0, "id": 0, "number": 0, "takenSeats": 0, "totalSeats": 0 }, "movieScreeningTime": "10:10" } , { "id": 1, "movie": { "id": 1, "ageLimit": 0, "description": "string", "duration": "string", "genre": "string", "language": "string", "title": "The Matrix", "image" : "images/The_matrix.jpg", "rating" : 3, "youtube_link" : "https://www.youtube.com/embed/9ix7TUGVYIo" }, "theater": { "availableSeats": 0, "id": 1, "number": 0, "takenSeats": 0, "totalSeats": 0 }, "movieScreeningTime": "10:10" } ]')


console.log(data)

//rating
for(var i = 0  ; i < data.length ; i++){

  const stars = document.createElement("div")
  stars.className="stars"

  const ratingSpan = document.createElement("span")
  ratingSpan.innerText = "(" + data[i].movie.rating + ")"

  const rating = document.createElement("div")
  rating.className="rating"

  rating.appendChild(stars)
  rating.appendChild(ratingSpan)

  //MOVIES-BTNS 
  const bookBtn = document.createElement("a") 
  bookBtn.className = "book-btn"
  bookBtn.innerText = "Book Now"

  const trailerBtn = document.createElement("a") 
  trailerBtn.className = "trailer-btn"
  trailerBtn.href = data[i].movie.youtube_link

  const bxPlay = document.createElement("i")
  bxPlay.className= "bx bx-play"

  trailerBtn.appendChild(bxPlay);

  const moviesBtns = document.createElement("div")
  moviesBtns.className = "movies-btns"

  moviesBtns.appendChild(bookBtn)
  moviesBtns.appendChild(trailerBtn)

  //movie-title
  const movieTitle = document.createElement("h2")
  movieTitle.className = "movie-title"
  movieTitle.innerText= data[i].movie.title

  //box-text
  const boxText = document.createElement("div")
  boxText.className="box-text"

  boxText.appendChild(movieTitle)
  boxText.appendChild(rating)
  boxText.appendChild(moviesBtns)

  //movie-box-image
  const movieBoxImg = document.createElement("img")
  movieBoxImg.className="movie-box-img"; 
  movieBoxImg.src = data[i].movie.image
  movieBoxImg.alt = ""

  //movie-box

  const movieBox = document.createElement("div");
  movieBox.className = "movie-box"

  movieBox.appendChild(movieBoxImg)
  movieBox.appendChild(boxText)

  //movie-content
  const moviesContent = document.querySelector('#MOVIES_CONTENT')
  console.log(moviesContent)
  moviesContent.appendChild(movieBox)

}

// Home Swiper
var swiper = new Swiper(".home", {
  spaceBetween: 0,
  centeredSlides: true,
  autoplay: {
    delay: 500000,
    disableOnInteraction: false,
  },
  pagination: {
    el: ".swiper-pagination",
    clickable: true,
  },
});
// Swiper
var swiper = new Swiper(".upcoming-content", {
  slidesPerView: 1,
  spaceBetween: 10,
  autoplay: {
    delay: 5000,
    disableOnInteraction: false,
  },
  navigation: {
    nextEl: ".swiper-button-next",
    prevEl: ".swiper-button-prev",
  },
  breakpoints: {
    280: {
      slidesPerView: 1,
      spaceBetween: 10,
    },
    320: {
      slidesPerView: 1,
      spaceBetween: 10,
    },
    510: {
      slidesPerView: 2,
      spaceBetween: 10,
    },
    758: {
      slidesPerView: 3,
      spaceBetween: 15,
    },
    900: {
      slidesPerView: 4,
      spaceBetween: 20,
    },
  },
});
// Header Background Change
let header = document.querySelector("header");

window.addEventListener("scroll", () => {
  header.classList.toggle("shadow", window.scrollY > 0);
});
// Menu Open
let menu = document.querySelector(".menu-icon");
let navbar = document.querySelector(".navbar");

menu.onclick = () => {
  navbar.classList.toggle("open-menu");
  menu.classList.toggle("move");
};
window.onscroll = () =>{
  navbar.classList.remove("open-menu");
  menu.classList.remove("move");
}


function addMovie(){
  const movie =
  {
    "ageLimit": 0,
    "description": "string",
    "duration": "string",
    "genre": "string",
    "id": 0,
    "language": "string",
    "title": "string"
  }
movie.ageLimit = document.querySelector("#ageLimit")
movie.description = document.querySelector("#description")
//osv ... 
var myHeaders = new Headers();
myHeaders.append("Authorization", "Bearer N2JlNjlkMTUtNzJlMy00OTUzLWJmZTktY2U3NTk2YzI0YWZi");
myHeaders.append("Content-Type", "application/json");

var movieBodyRequest = JSON.stringify(movie);

var requestOptions = {
  method: 'POST',
  headers: myHeaders,
  body: movieBodyRequest,
  redirect: 'follow'
};

fetch("http://localhost:8081/api/movie", requestOptions)
  .then(response => {
    if( response.status = 200){
      // Movie added sucessfully 
      // --> Gå vidare
    }
  })
  .catch(error => console.log('error', error));

}






























console.log("Cinema")
// get allMovie
 async function getAllMovies(){

    const response  =  await fetch('http://localhost:8081/api/movie/all') // get all movies från backend
  
    var movies = await response.json(); //sparar resultatet i movies

    console.log(movies)

    let moviesDIV = document.getElementById("movies");  // pekar på DIV vi vill ändra i
     
    for( var index = 0 ;  index < movies.length  ; index++ ){
        //Lägg till följande HTML i varje loop iteration 
        moviesDIV.innerHTML += 
        `
        <tr>
            <th scope="row">${index + 1}</th>
            <td>${movies[index].title}</td>
            <td>${movies[index].rating}</td>
            <td>${movies[index].duration}</td>
            <td>${movies[index].genre}</td>
            <td>${movies[index].language}</td>
            <td>${movies[index].ageLimit}</td>  
            <td id="movies_${movies[index].movieId}">
                <button onclick="deleteMovieById(event)" type="button" class="btn btn-danger btn-sm">delete</button> 
                <button onclick="editMovieById(event)" type="button" class="btn btn-warning btn-sm">edit</button>
                <a href="/Alex Movies Website 3/Admin/Movies/Movie2.html"> more_info </a>
            </td>
        </tr>
         `

   }  
}
 

// Add movie 


async function  skapaMovie  ()  {
       
    alert("Vad som helst") 
    var myHeaders = new Headers();
    myHeaders.append("Content-Type", "application/json");

    var raw = JSON.stringify({
        "id"  :  null ,  
        "title": document.getElementById("title").value ,
        "image": document.getElementById("image").value ,
        "rating": document.getElementById("rating").value,
        "youtube_link": document.getElementById("youtube_link").value    ,
        "description": document.getElementById("description").value   ,
        "duration": document.getElementById("duration").value  ,
        "genre":  document.getElementById("genre").value  ,
        "language": document.getElementById("language").value  ,
        "ageLimit": document.getElementById("ageLimit").value  


        
    });

    var requestOptions = {
        method: 'POST',
        headers: myHeaders,
        body: raw,
        redirect: 'follow'
    };

    const response = await fetch("http://localhost:8081/api/movie", requestOptions); 
    let movieResponse = await response.json()
    console.log(movieResponse); 
}



       
    function deleteMovieById(e){
        console.log("Vad som helst") 
        var parent  = e.target.parentElement ; 
        var row = parent.parentElement; 
        var movie_id = parent.id
        var realMovieId = movie_id.split("_")[1];  
        console.log(e.target)
        console.log(parent)
        console.log(row)
        console.log(movie_id)
       
    
        console.log("REAL MOVIE ID " + realMovieId)
        // API ANROP 
        // delete By ID i API:ET 
        var response = {
            statusCode : 200
        }
    
        if( response.statusCode == 200){
            row.remove(); 
        }
        else{
            alert("KUNDE INTE DELETE MOVIE MED ID: " +  realMovieId)
        }
    }
    // delete movieById
    async function deleteMovieByIdD(e){
    
        console.log(e.target.parentElement.id); 
    
        var rawMovieId =  e.target.parentElement.id  ;  // "movie_11"
        var realMovieId = rawMovieId.split("_")[1];   //   [0] _[1]   
    
        var requestOptions = {
            method: 'DELETE',
            redirect: 'follow',
            };
    
        const response =  await fetch('http://localhost:8081/api/movie' + realMovieId, requestOptions)
        var movie_deleted = await response.json(); //sparar resultatet i movies
    
        console.log(movie_deleted); 

        }
    
          // update movieByID
        async function editMovieById(e){

            console.log(e.target); 
        }
        



              async function getElementById(movieId){

                console.log(window.location.search)
              

                var raw = "";

                var requestOptions = {
                  method: 'GET',
                  body: raw,
                  redirect: 'follow'
                };
                

                await fetch("localhost:8081/api/movie/" + realMovieId, requestOptions)
                console.log(window.location.search)
              alert("varför?")

                console.log(window.location.search)


              }

            

   // getAllMovies();
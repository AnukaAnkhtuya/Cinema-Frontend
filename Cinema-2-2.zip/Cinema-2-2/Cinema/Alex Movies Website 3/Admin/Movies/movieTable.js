console.log("Cinema")
// get allMovie
 async function getAllMovies(){

    const response  =  await fetch('http://localhost:8081/api/movie/all') // get all movies från backend
  
    var movies = await response.json(); //sparar resultatet i movies

    console.log(movies)

    let moviesDIV = document.getElementById("movies");  // pekar på DIV vi vill ändra i
     
    for( var index = 0 ;  index < movies.length  ; index++ ){
        let currentMovie = movies[index] ; 
     //Lägg till följande HTML i varje loop iteration 
        moviesDIV.innerHTML += 
        `
        <tr>
            <th scope="row">${index + 1}</th>
            <td>${currentMovie.title}</td>
            <td>${currentMovie.rating}</td>
            <td>${currentMovie.duration}</td>
            <td>${currentMovie.genre}</td>
            <td>${currentMovie.language}</td> 
            <td>${currentMovie.ageLimit}</td>  
            <td id="movies_${currentMovie.movieId}">
                <button onclick="deleteMovieById(event)" type="button" class="btn btn-danger btn-sm">delete</button> 
                <button onclick="editMovieById(event)" type="button" class="btn btn-warning btn-sm">edit</button>
                <a href="./Movie2.html?id=${currentMovie.movieId}"> more_info </a>
               
            </td>
        </tr>
         `
   }
}

async function deleteMovieById(e){

    console.log("deleted movie By Id!")
    console.log(e.target)
    var parent  = e.target.parentElement ; 
    var movie_id = parent.id
    var realMovieId = movie_id.split("_")[1];  
    var row = parent.parentElement; 
    
    var requestOptions = {
        method: 'DELETE',
        redirect: 'follow',
        };

    const response =  await fetch('http://localhost:8081/api/movie/' + realMovieId, requestOptions)

    var movie_deleted = await response; //sparar resultatet i movies
    console.log(movie_deleted)

    if(movie_deleted.ok == true){
        row.remove()
    }
    else{
        alert("SOMETHING WENT WRONG COULD DELETE MOVIE ")
    }

}
// update movieByID
async function editMovieById(e){

    console.log(e.target); 
    var parent  = e.target.parentElement ; 
    var movie_id = parent.id
    var realMovieId = movie_id.split("_")[1];  
  
}
         
getAllMovies()





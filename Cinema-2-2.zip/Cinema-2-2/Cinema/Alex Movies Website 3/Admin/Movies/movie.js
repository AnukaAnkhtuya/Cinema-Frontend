console.log("HEJ")

async function getMovieById(){


    var movie_id = window.location.search.split("=")[1]; 

    var requestOptions = {
      method: 'GET',
      redirect: 'follow'
    };
    
    const response = await fetch("http://localhost:8081/api/movie/" + movie_id, requestOptions) 

    let movie = await response.json();

    populateHTML(movie); 
}


function populateHTML(movie){

    var movie_box = document.getElementById("content")

    var rating_stars = 

    movie_box.innerHTML = 
    `
    <div class="movie-box">
    <img  src="${movie.image}" alt="" class="movie-box-img">
    <div class="box-text">
        <h2 class="movie-title">${movie.title}</h2>
        <div class="rating">
            <div class="stars">
                ${populateStars(movie.rating)}
            </div>
            <span>(${movie.rating})</span>
        </div>
        <div class="movies-btns">
            <a href="#" class="book-btn">Book Now</a>
            <a href="${movie.youtube_link}" class="trailer-btn">
                <i class='bx bx-play' ></i>
            </a>
        </div>
        <div>
            <p> ${movie.description}</p>
        <div>
    </div>
    </div>
   <!-- <div> ${movie.youtube_link}</div>-->
    `
    console.log(movie)
}

function populateStars(rating) {
    let rating_stars = ''

for ( var i = 0 ;  i < rating ; i++ ){ //Loopen körs Rating Antal gånger
        rating_stars +=
         `
            <i class='bx bxs-star' >X</i>
        `
    }
    return rating_stars ; 
}
getMovieById();
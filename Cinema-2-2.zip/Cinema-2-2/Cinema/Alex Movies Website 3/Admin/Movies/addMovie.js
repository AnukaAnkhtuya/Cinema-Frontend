async function addMovie() {

    var myHeaders = new Headers();
    myHeaders.append("Content-Type", "application/json");


    var raw = JSON.stringify({
        "id": null,
        "title": document.getElementById("title").value,
        "image": document.getElementById("image").value,
        "rating": document.getElementById("rating").value,
        "youtube_link": document.getElementById("youtube_link").value,
        "description": document.getElementById("description").value,
        "duration": document.getElementById("duration").value,
        "genre": document.getElementById("genre").value,
        "language": document.getElementById("language").value,
        "ageLimit": document.getElementById("ageLimit").value
    });

    var requestOptions = {
        method: 'POST',
        headers: myHeaders,
        body: raw,
        redirect: 'follow'
    };

    const response =  await fetch("http://localhost:8081/api/movie", requestOptions);
    let movie_added = await response;

    if(movie_added.ok == true){

        location.href = './movieTable.html';

       //Gör nått
    }
    else{
        alert("SOMETHING WENT WRONG! COULD ADD MOVIE ")
    }
    console.log(movie_added);

}
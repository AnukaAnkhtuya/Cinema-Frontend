async function addStaff() {

    var myHeaders = new Headers();
    myHeaders.append("Content-Type", "application/json");


    var raw = JSON.stringify({
        "id": null,
        "fullName": document.getElementById("fullName").value,
        "userName": document.getElementById("userName").value,
        "password": document.getElementById("password").value,
        
    });

    var requestOptions = {
        method: 'POST',
        headers: myHeaders,
        body: raw,
        redirect: 'follow'
    };

    const response =  await fetch("http://localhost:8081/api/staff", requestOptions);
    let staff_added = await response;

    if(staff_added.ok == true){

        location.href = './staffTable.html';

       //Gör nått
    }
    else{
        alert("SOMETHING WENT WRONG! COULD NOT ADD STAFF ")
    }
    console.log(staff_added);

}

console.log("Cinema")
// get allMovie
async function getAllMovieScreening(){

    const response  =  await fetch('http://localhost:8081/api/MS/all') // get all movie screening från backend
  
    var movieScreening = await response.json(); //sparar resultatet i movies

    console.log(movieScreening)

    let movieScreeningDIV = document.getElementById("movieScreening");  // pekar på DIV vi vill ändra i

    for( var index = 0 ;  index < movieScreening.length  ; index++ ){
  
     //Lägg till följande HTML i varje loop iteration 
        movieScreeningDIV.innerHTML += 
        `
        <tr>
            <th scope="row">${index + 1}</th>
            <td>${movieScreening[index].theater.number}</td>
            <td>${movieScreening[index].movie.title}</td>
            <td>${movieScreening[index].movieScreeningTime}</td>
            <td>${movieScreening[index].theater.takenSeats}</td>
            <td id="movies_${movieScreening[index].movieScreeningId}">
                <button onclick="deleteMovieScreeningById(event)" type="button" class="btn btn-danger btn-sm">delete</button> 
                <button onclick="editMovieScreeningById(event)" type="button" class="btn btn-warning btn-sm">edit</button>
                <a href="./Movie2.html?id=${movieScreening[index].movieScreeningId}"> more_info </a>
               
            </td>
        </tr>
         `
   }
}

async function deleteMovieScreeningById(e){

    console.log("deleted movie Screening By Id!")
    console.log(e.target)
    var parent  = e.target.parentElement ; 
    var movieScreening_id = parent.id
    var realMovieScreeningId = movieScreening_id.split("_")[1];  
    var row = parent.parentElement; 
    
    var requestOptions = {
        method: 'DELETE',
        redirect: 'follow',
        };

    const response =  await fetch('http://localhost:8081/api/MS/' + realMovieScreeningId, requestOptions)

    var movieScreening_deleted = await response; //sparar resultatet i movieScreening
    console.log(movieScreening_deleted)

    if(movieScreening_deleted.ok == true){
        row.remove()
    }
    else{
        alert("SOMETHING WENT WRONG COULD NOT DELETE MOVIESCREENING ")
    }

}
// update movieByID
async function editMovieScreeningById(e){

    console.log(e.target); 
    var parent  = e.target.parentElement ; 
    var movie_id = parent.id
    var realMovieScreeningId = movie_id.split("_")[1];  
  
}
         
getAllMovieScreening()





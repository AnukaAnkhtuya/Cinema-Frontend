async function addMovieScreening() {

    var myHeaders = new Headers();
    myHeaders.append("Content-Type", "application/json");


    let movie_id = getIdOfChosenMovie()
    let theater_id = getIdOfChosenTheater()
    let movieScreeningTime = undefined; 

    if (document.getElementById("movie_screening_time_selector").value != 'not_an_option'){
        movieScreeningTime = document.getElementById("movie_screening_time_selector").value
    }
  
    var bodyRequest = JSON.stringify({
        "movieId": movie_id,
        "theaterId": theater_id,
        "movieScreeningTime": movieScreeningTime
    });

    var requestOptions = {
        method: 'POST',
        headers: myHeaders,
        body: bodyRequest,
        redirect: 'follow'
    };
    if(movie_id && theater_id && movieScreeningTime){
        const response =  await fetch("http://localhost:8081/api/MS/", requestOptions);
    
        let movieScreening_added = await response;
    
        if(movieScreening_added.ok == true){
    
            location.href = './screeningTable.html';
    
           //Gör nått
        }
        else{
            alert("SOMETHING WENT WRONG! COULD ADD MOVIESCREENING")
        }
      
    }else{
        alert("Please fill in all the options")
    }


}

function getIdOfChosenMovie(){
    var movie_id = null
    var movie_selector =  document.getElementById("movie_selector")

    if(isNaN(movie_selector.value)){ //Kontrollerar så att man har inte valt någon movie
        return; 
    }

    movie_id = movie_selector.value 
    return movie_id; 
}

function getIdOfChosenTheater(){
    var theater_id = null
    var theater_selector =  document.getElementById("theater_selector")

    if(isNaN(theater_selector.value)){ //Kontrollerar så att man har inte valt någon movie
        return; 
    }

    theater_id = theater_selector.value 
    return theater_id; 

}

async function getAllMovies(){
    const response  =  await fetch('http://localhost:8081/api/movie/all') // get all movies från backend
  
    var movies = await response.json(); //sparar resultatet i movies
    
    console.log("ALL movies")
    console.log(movies)

   var movies_options = document.getElementById("movie_selector") 
   console.log(movies_options)

   movies_options.innerHTML =    `<option value="default" selected>Choose a Movie</option>`
    for(var index = 0; index < movies.length; index++)
    {
        var currentMovie = movies[index]; 

        movies_options.innerHTML += 
            `
                <option value="${currentMovie.movieId}">${currentMovie.title}</option>

            `
    } 


}

async function getAllTheater(){
    const response  =  await fetch('http://localhost:8081/api/theater') // get all theater från backend
  
    var theaters  = await response.json(); //sparar resultatet i theater

    console.log("ALL theater")
    console.log(theaters)

    var theater_options = document.getElementById("theater_selector") 
    console.log(theater_options)
 
    theater_options.innerHTML =    `<option value="default" selected>Choose a Theater</option>`
     for(var index = 0; index < theaters.length; index++)
     {
         var currentTheater = theaters[index]; 
 
         theater_options.innerHTML += 
             `
                 <option value="${currentTheater.theaterId}">${currentTheater.number}</option>
 
             `
     } 

    

}


getAllMovies();
getAllTheater(); 

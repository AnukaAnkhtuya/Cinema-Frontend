async function addCustomer() {

    var myHeaders = new Headers();
    myHeaders.append("Content-Type", "application/json");


    var raw = JSON.stringify({
        "id": null,
        "firstName": document.getElementById("firstName").value,
        "lastName": document.getElementById("lastName").value,
        "email": document.getElementById("email").value,
        "phone": document.getElementById("phone").value,
        
    });

    var requestOptions = {
        method: 'POST',
        headers: myHeaders,
        body: raw,
        redirect: 'follow'
    };

    const response =  await fetch("http://localhost:8081/api/customer", requestOptions);
    let customer_added = await response;

    if(customer_added.ok == true){

        location.href = './customerTable.html';

       //Gör nått
    }
    else{
        alert("SOMETHING WENT WRONG! COULD NOT ADD CUSTOMER ")
    }
    console.log(customer_added);

}
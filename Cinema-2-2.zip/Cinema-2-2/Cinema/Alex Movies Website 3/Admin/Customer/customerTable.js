console.log("Cinema")
// get allMovie
 async function getAllCustomers(){

    const response  =  await fetch('http://localhost:8081/api/customer/all') // get all movies från backend
  
    var customers = await response.json(); //sparar resultatet i movies

    console.log(customers)

    let customersDIV = document.getElementById("customers");  // pekar på DIV vi vill ändra i
     
    for( var index = 0 ;  index < customers.length  ; index++ ){
  
     //Lägg till följande HTML i varje loop iteration 
     customersDIV.innerHTML += 
        `
        <tr>
            <th scope="row">${index+1}</th>
            <td>${customers[index].firstName}</td>
            <td>${customers[index].lastName}</td>
            <td>${customers[index].email}</td>
            <td>${customers[index].phone}</td>
            <td id="customers_${customers[index].id}">
                <button onclick="deleteCustomerById(event)" type="button" class="btn btn-danger btn-sm">delete</button> 
                <button onclick="editCustomerById(event)" type="button" class="btn btn-warning btn-sm">edit</button>
                <a href="./customer2.html?id=${customers[index].id}"> more_info </a>
            </td>
        </tr>
         `
   }
}

async function deleteCustomerById(e){

    console.log("deleted customer By Id!")
    console.log(e.target)
    var parent  = e.target.parentElement ; 
    var id = parent.id
    var realId = id.split("_")[1];  
    var row = parent.parentElement; 
    
    var requestOptions = {
        method: 'DELETE',
        redirect: 'follow',
        };

    const response =  await fetch('http://localhost:8081/api/customer/' + realId, requestOptions)

    var customer_deleted = await response; //sparar resultatet i movies
    console.log(customer_deleted)

    if(customer_deleted.ok == true){
        row.remove()
    }
    else{
        alert("SOMETHING WENT WRONG COULD NOT DELETE CUSTOMER ")
    }

}
// update movieByID
async function editCustomerById(e){

    console.log(e.target); 
    var parent  = e.target.parentElement ; 
    var id = parent.id
    var realId = id.split("_")[1];  
  
}
         
getAllCustomers()





console.log("HEJ")

async function getCutomerById(){


    var customer_id = window.location.search.split("=")[1]; 

    var requestOptions = {
      method: 'GET',
      redirect: 'follow'
    };
    
    const response = await fetch("http://localhost:8081/api/customer/" + customer_id, requestOptions) 

    let customer= await response.json();

    populateHTML(customer); 
}


function populateHTML(customer){

    var customer_box = document.getElementById("content")


    customer_box.innerHTML = 
   
    console.log(movie)
}

 
getCutomerById();
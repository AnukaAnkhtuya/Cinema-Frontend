// get allTicket
 async function getAllTicket(){

    const response  =  await fetch('http://localhost:8081/api/ticket/all') // get all ticket från backend
  
    var tickets  = await response.json(); //sparar resultatet i ticket

    console.log(tickets)


    let TicketDIV = document.getElementById("ticket");  // pekar på DIV vi vill ändra i
     
    for( var index = 0 ;  index < tickets.length  ; index++ ) {
        let currentTicket = tickets[index]
     //Lägg till följande HTML i varje loop iteration 
        TicketDIV.innerHTML += 
        `
        <tr>
            <th scope="row">${index + 1}</th>
            <td>${currentTicket.movieScreening.movie.title}</td>  
            <td>${currentTicket.movieScreening.theater.number}</td>  
            <td>${currentTicket.movieScreening.movieScreeningTime}</td>  
            <td>${currentTicket.price}</td>  
            <td>${currentTicket.seat}</td>  
            <td id="movies_${currentTicket.id}">
                <button onclick="deleteTicketById(event)" type="button" class="btn btn-danger btn-sm">delete</button> 
                <button onclick="editTicketById(event)" type="button" class="btn btn-warning btn-sm">edit</button>
                <a href="./ticket2.html?id=${currentTicket.id}"> more_info </a>
            </td>
        </tr>
         `
   }
}





async function deleteTicketById(e){

    console.log("deleted Ticket By Id!")
    console.log(e.target)
    var parent  = e.target.parentElement ; 
    var ticket_id = parent.id
    var realTicket_Id = ticket_id.split("_")[1];  
    var row = parent.parentElement; 
    
    var requestOptions = {
        method: 'DELETE',
        redirect: 'follow',
        };

    const response =  await fetch('http://localhost:8081/api/ticket/' + realTicket_Id, requestOptions)

    var ticket_deleted = response; //sparar resultatet i theater
    console.log(ticket_deleted)

    if(ticket_deleted.ok == true){
        row.remove()
    }
    else{
        alert("SOMETHING WENT WRONG COULD NOT DELETE TICKET ")
    }

}
// update movieByID
async function editTicketById(e){

    console.log(e.target); 
    var parent  = e.target.parentElement ; 
    var ticket_id = parent.id
    var realTicket_Id = ticket_id.split("_")[1];  
  
}
         
getAllTicket()





 async function populateMovieScreenings(){

    const response  =  await fetch('http://localhost:8081/api/MS/all') // get all movie screening från backend
  
    var movieScreening = await response.json(); //sparar resultatet i movies

    console.log(movieScreening)

    let movieScreeningDIV = document.getElementById("movieScreeningsCards");  // pekar på DIV vi vill ändra i

    for( var index = 0 ;  index < movieScreening.length  ; index++ ){
        let currentScreening = movieScreening[index]; 

     //Lägg till följande HTML i varje loop iteration 
        movieScreeningDIV.innerHTML += 
        `
        <div class="card movieScreeningsCard" style="width: 18rem;">
            <div class="card-body">
            <h5 class="card-title">${currentScreening.movie.title}</h5>
            </div>
            <ul class="list-group list-group-flush">
            <li class="list-group-item"><b>Theater nummer:</b>${currentScreening.theater.number}</li>
            <li class="list-group-item"><b>Screening Time:</b>${currentScreening.movieScreeningTime}</li>
            </ul>
            <div  class="card-body">
                <input class="form-check-input movie_screening_radio_buttons" name="flexRadioDefault" type="radio"  id="${currentScreening.movieScreeningId}">
                <label class="form-check-label" for="flexRadioDefault">
                Default radio
                </label>
            </div>
        </div>

         `
   }
}

async function addTicket(ticket){
    
    var myHeaders = new Headers();
    myHeaders.append("Content-Type", "application/json");
    


    //Seat
    if(document.getElementById("seats_selector").value == 'not_an_option') {
        alert("Please choose a Seat")
        return; 
    }
    var seat = document.getElementById("seats_selector").value ; 
    
    //Price
    if(isNaN(document.getElementById("price").value) || document.getElementById("price").value == '' ){ //Kontrollerar så att man har inte valt någon movie
        alert("Price ska vara ett NUMMER")
        return; 
    }
    var price = document.getElementById("price").value; 


    //MovieScreening
    var movieScreening_id = getChosenMovieScreeningID()


    //REQUEST BODY 
    var bodyRequest = JSON.stringify(
        {
            "movieScreeningID": movieScreening_id,
            "price": price,
            "seat": seat
        }
    ); 

    var requestOptions = {
        method: 'POST',
        headers: myHeaders,
        body: bodyRequest, //REQUEST BODY
        redirect: 'follow'
    };


    
    if(price && seat && movieScreening_id){

        const response =  await fetch('http://localhost:8081/api/ticket', requestOptions)
        let ticket_added = await response;
        console.log(ticket_added)
        if(ticket_added.ok == true){ //TODO IF CREATED 201 ? 
    
            location.href = './ticketTable.html';
        }
        else{
            alert("SOMETHING WENT WRONG! COULD NOT ADD TICKET")
        }
      
    }

}

// delete metoden anrop
    
function getChosenMovieScreeningID(){
    var movieScreening_id = undefined ; 
    // 
    var allRadioButtons = document.getElementsByClassName("movie_screening_radio_buttons")

    for( var index = 0 ; index < allRadioButtons.length ; index++){

        let movie_screening = allRadioButtons[index]; 
        
        if(movie_screening.checked){
            console.log(movie_screening)
            movieScreening_id = movie_screening.id
            break;
        }

        if(index == allRadioButtons.length - 1) {
            alert("Please choose a MovieScreening")
        }

    }

    return movieScreening_id; 
}

populateMovieScreenings();
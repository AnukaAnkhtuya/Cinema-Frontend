console.log("Theater")
async function addTheater(theater){

    var myHeaders = new Headers();
    myHeaders.append("Content-Type", "application/json");

    var raw = JSON.stringify({
        "id": null,
        "number": document.getElementById("number").value,
        "availableSeats": document.getElementById("availableSeats").value,
        "takenSeats": document.getElementById("takenSeats").value,
        "totalSeats": document.getElementById("totalSeats").value,      
    });
    var requestOptions = {
        method: 'POST',
        headers: myHeaders,
        body: raw,
        redirect: 'follow'
    };

    const response =  await fetch("http://localhost:8081/api/theater", requestOptions);
    let theater_added =  await response;
    

    if(theater_added.ok == true){

        location.href = './theaterTable.html';

       //Gör nått
    }
    else{
        alert("SOMETHING WENT WRONG! COULD NOT ADD THEATER ")
    }
    console.log(theater_added);

}
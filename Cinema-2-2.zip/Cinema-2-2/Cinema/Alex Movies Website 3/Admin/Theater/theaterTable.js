console.log("Cinema")
// get allTheater
 async function getAllTheater(){

    const response  =  await fetch('http://localhost:8081/api/theater') // get all theater från backend
  
    var theater  = await response.json(); //sparar resultatet i theater

    console.log(theater)

    let theaterDIV = document.getElementById("theater");  // pekar på DIV vi vill ändra i
     
    for( var index = 0 ;  index < theater.length  ; index++ ){
  
     //Lägg till följande HTML i varje loop iteration 
        theaterDIV.innerHTML += 


        `
        <tr>
            <th scope="row">${index + 1}</th>
            <td>${theater[index].number}</td>
            <td>${theater[index].availableSeats}</td>
            <td>${theater[index].takenSeats}</td>
            <td>${theater[index].totalSeats}</td>  
            <td id="movies_${theater[index].theaterId}">
                <button onclick="deleteTheaterById(event)" type="button" class="btn btn-danger btn-sm">delete</button> 
                <button onclick="editTheaterById(event)" type="button" class="btn btn-warning btn-sm">edit</button>
                <a href="./Theater2.html?id=${theater[index].theaterId}"> more_info </a>
               
            </td>
        </tr>
         `
   }
}





async function deleteTheaterById(e){

    console.log("deleted Theater By Id!")
    console.log(e.target)
    var parent  = e.target.parentElement ; 
    var theater_id = parent.id
    var realTheater_Id = theater_id.split("_")[1];  
    var row = parent.parentElement; 
    
    var requestOptions = {
        method: 'DELETE',
        redirect: 'follow',
        };

    const response =  await fetch('http://localhost:8081/api/theater/' + realTheater_Id, requestOptions)

    var theater_deleted = await response; //sparar resultatet i theater
    console.log(theater_deleted)

    if(theater_deleted.ok == true){
        row.remove()
    }
    else{
        alert("SOMETHING WENT WRONG COULD DELETE THEATER ")
    }

}
// update movieByID
async function editTheaterById(e){

    console.log(e.target); 
    var parent  = e.target.parentElement ; 
    var theater_id = parent.id
    var realTheaterId = theater_id.split("_")[1];  
  
}
         
getAllTheater()





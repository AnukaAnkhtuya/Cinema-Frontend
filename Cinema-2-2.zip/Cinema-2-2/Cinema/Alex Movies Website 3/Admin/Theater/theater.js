console.log("HEj theater")

async function getTheaterById(){

  var theater_id = window.location.search.split("=")[1];
      

  var requestOptions = {
    method: 'GET',
    redirect: 'follow'
  };
      const response = await fetch("http://localhost:8081/api/theater/" + theater_id ,requestOptions)

    
   let theater = await response.json();
   populateHTML(theater); 
     
}

function populateHTML(theater){
  var theater_box = document.getElementById("content")

  theater_box.innerHTML=

  `
  <div class="theater_box">
  <div class="box-text">
      <h2 class="theater-number">${theater.number}</h2>
      <div class="takenSeats">
          <div class="takenSeats>
              ${populateStars(theater.avaiblleSeats)}
          </div>
          <span>(${theater.avaiblleSeats})</span>
      </div>
      `
     
  console.log(movie)
}


getTheaterById();